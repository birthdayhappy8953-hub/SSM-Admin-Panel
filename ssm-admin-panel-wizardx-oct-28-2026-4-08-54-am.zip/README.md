# SSM Admin Panel — WizardX

A modern, responsive SSM Admin Panel inspired by the WizardX interface, built with React, Vite, Tailwind CSS, and Firebase (Authentication, Cloud Firestore, and Firebase Hosting).

---

## Features

- **Dashboard UI**:
  - Blue 4-squares app logo.
  - Live total device count badge (`361`).
  - Real-time live date and time displayed in crimson red font (`DD/MM/YYYY hh:mm:ss a`).
  - Search bar with `"Enter Number To Seach"` and circular blue search button.
  - Device cards with smartphone thumbnail, black ID badge, connection status, battery percentage, Wi-Fi connectivity indicator, demon avatar, and quick action buttons.
  - Mobile Device Frame toggle to switch between exact smartphone preview and wide desktop view.

- **Messages & Old Messages**:
  - Full-width black button labeled **"Show Form Data"**.
  - Message cards with black sender/header pill (`JM-HDFCBN-P`, `AD-650025-P`, `AD-ISATHI-G`).
  - Message body with clean typography.
  - Timestamps aligned to bottom-right (`25/02/2026 03:17:01 pm`).
  - Instant copy and keyword filtering.

- **Page Form Data Modal**:
  - Modal title: `[ 1 ] Page Form Data`.
  - Displays submitted form key-value pairs (`dob => ...`, `id => ...`, `mobile => ...`, `name => ...`, `pan => ...`).
  - Pagination between form submissions.
  - Privacy masking toggle (protects PII by default with administrator reveal).
  - One-click data copy.

- **Device Action & Settings Popup (`id41`)**:
  - 5 dark rounded pill buttons with colored icons:
    1. **Change Password**: Secure password update form.
    2. **Change Number**: Updates administrator verified contact number.
    3. **Change TeleBot**: Telegram Bot Token and Chat ID integration.
    4. **Contact Admin**: Priority support hotline, Telegram handle, and email.
    5. **Identity Logout**: Sign out using Firebase Authentication.

- **SIM Management & Forwarding Modal**:
  - Dual SIM radio selection (`8839803911 / airtel`, `not available`).
  - Number input.
  - `ACTIVATE`, `DEACTIVATE`, and `CHECK ACTIVATION` buttons.

- **Send SMS Modal**:
  - Dual SIM selector.
  - `Address here` and `Message here` inputs.
  - `SEND SMS` action with instant live feedback and audit log entry.

- **Firebase Status & Firestore Center**:
  - Live indicator of Firebase connection.
  - Firestore collections status (`users`, `devices`, `messages`, `oldMessages`, `formRecords`, `appSettings`, `auditLogs`).
  - One-click Firestore initial data seeder.
  - Built-in audit log monitor.

---

## Project Structure

```
├── firestore.rules          # Cloud Firestore Security Rules with RBAC
├── firebase.json            # Firebase Hosting and Firestore config
├── .env.example             # Environment variable template
├── src/
│   ├── components/
│   │   ├── DeviceCard.tsx          # Device card matching screenshot 1
│   │   ├── FirebaseStatusModal.tsx # Firebase configuration & seeder
│   │   ├── FormDataModal.tsx       # Page Form Data matching screenshot 5
│   │   ├── Header.tsx              # Top header with ticking clock & count
│   │   ├── Icons.tsx               # 4-square logo & demon icon
│   │   ├── LoginView.tsx           # Authentication screen
│   │   ├── MessagesView.tsx        # Message viewer matching screenshot 2
│   │   ├── SearchBar.tsx           # Search input matching screenshot 1
│   │   ├── SendSmsModal.tsx        # Quick SMS matching screenshot 6
│   │   ├── SettingsMenuModal.tsx   # Action popup matching screenshot 3
│   │   └── SimActivationModal.tsx  # SIM activation matching screenshot 4
│   ├── context/
│   │   └── AuthContext.tsx         # Firebase Auth & session management
│   ├── data/
│   │   └── mockData.ts             # Realistic sample seed data
│   ├── firebase/
│   │   └── config.ts               # Firebase SDK initialization
│   ├── services/
│   │   └── firestoreService.ts     # Firestore CRUD & audit logging
│   ├── types/
│   │   └── index.ts                # TypeScript interfaces
│   ├── App.tsx                     # Main layout & router
│   ├── index.css                   # Tailwind styles
│   └── main.tsx                    # React root
```

---

## Local Development & Firebase Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Firebase Environment Variables
Copy `.env.example` to `.env` and fill in your Firebase Web App credentials:
```env
VITE_FIREBASE_API_KEY="AIzaSy..."
VITE_FIREBASE_AUTH_DOMAIN="your-app.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-app.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="123456789012"
VITE_FIREBASE_APP_ID="1:123456789012:web:abcdef"
```

*Note: If no Firebase keys are set, the app will run in Interactive Preview Mode with full local persistence and seed data.*

### 3. Start Development Server
```bash
npm run dev
```

### 4. Deploying to Firebase
1. Install Firebase CLI:
   ```bash
   npm install -g firebase-tools
   ```
2. Log in and initialize:
   ```bash
   firebase login
   firebase use --add <your-project-id>
   ```
3. Deploy Firestore rules and hosting:
   ```bash
   npm run build
   firebase deploy
   ```
