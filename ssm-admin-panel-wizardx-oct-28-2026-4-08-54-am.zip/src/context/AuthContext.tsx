import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updatePassword as firebaseUpdatePassword,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../firebase/config';
import { UserProfile } from '../types';
import { INITIAL_USER } from '../data/mockData';
import { logAuditEvent } from '../services/firestoreService';

interface AuthContextType {
  currentUser: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  isAdmin: boolean;
  isFirebaseActive: boolean;
  loading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updatePassword: (newPass: string) => Promise<{ success: boolean; error?: string }>;
  updateUserContact: (contact: string) => Promise<{ success: boolean; error?: string }>;
  updateTeleBot: (token: string, chatId: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_USER_KEY = 'ssm_current_user_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_USER_KEY);
      return stored ? JSON.parse(stored) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);

  const isFirebaseActive = isFirebaseConfigured();

  useEffect(() => {
    if (isFirebaseActive && auth) {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setFirebaseUser(user);
        if (user) {
          const profile: UserProfile = {
            uid: user.uid,
            email: user.email || 'admin@wizardx.panel',
            displayName: user.displayName || 'Admin (id41)',
            role: user.email?.includes('admin') ? 'admin' : 'admin',
            status: 'active',
            contactNumber: currentUser?.contactNumber || '+91 8839803911',
            createdAt: user.metadata.creationTime || new Date().toISOString(),
          };
          setCurrentUser(profile);
          localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(profile));
        }
        setLoading(false);
      });
      return () => unsubscribe();
    } else {
      setLoading(false);
    }
  }, [isFirebaseActive]);

  const login = async (email: string, pass: string) => {
    try {
      if (isFirebaseActive && auth) {
        const userCredential = await signInWithEmailAndPassword(auth, email, pass);
        const fUser = userCredential.user;
        const profile: UserProfile = {
          uid: fUser.uid,
          email: fUser.email || email,
          displayName: fUser.displayName || 'Admin (id41)',
          role: 'admin',
          status: 'active',
          contactNumber: '+91 8839803911',
          createdAt: new Date().toISOString(),
        };
        setCurrentUser(profile);
        localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(profile));
        await logAuditEvent('USER_LOGIN', `Authenticated via Firebase Auth: ${email}`, profile.uid, email);
        return { success: true };
      } else {
        // Local preview simulation
        const profile: UserProfile = {
          ...INITIAL_USER,
          email,
          displayName: email.includes('admin') ? 'Admin (id41)' : 'User (id18)',
          role: email.includes('user') ? 'user' : 'admin',
        };
        setCurrentUser(profile);
        localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(profile));
        await logAuditEvent('USER_LOGIN', `Logged into WizardX panel (Local/Preview): ${email}`, profile.uid, email);
        return { success: true };
      }
    } catch (err: any) {
      return { success: false, error: err?.message || 'Login failed' };
    }
  };

  const logout = async () => {
    try {
      if (currentUser) {
        await logAuditEvent('IDENTITY_LOGOUT', `User ${currentUser.email} logged out`, currentUser.uid, currentUser.email);
      }
      if (isFirebaseActive && auth) {
        await firebaseSignOut(auth);
      }
      setCurrentUser(null);
      localStorage.removeItem(LOCAL_USER_KEY);
    } catch (err) {
      console.error('Error during logout:', err);
    }
  };

  const updatePassword = async (newPass: string) => {
    if (!newPass || newPass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters.' };
    }
    try {
      if (isFirebaseActive && auth && auth.currentUser) {
        await firebaseUpdatePassword(auth.currentUser, newPass);
      }
      await logAuditEvent('PASSWORD_CHANGE', 'Account password successfully updated', currentUser?.uid || 'usr-admin-1', currentUser?.email);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to update password.' };
    }
  };

  const updateUserContact = async (contact: string) => {
    if (!contact.trim()) {
      return { success: false, error: 'Phone number cannot be empty.' };
    }
    if (currentUser) {
      const updated = { ...currentUser, contactNumber: contact.trim() };
      setCurrentUser(updated);
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(updated));
      await logAuditEvent('NUMBER_CHANGE', `Contact number updated to ${contact.trim()}`, currentUser.uid, currentUser.email);
      return { success: true };
    }
    return { success: false, error: 'No active session' };
  };

  const updateTeleBot = async (token: string, chatId: string) => {
    if (currentUser) {
      const updated = { ...currentUser, telegramBotToken: token, telegramChatId: chatId };
      setCurrentUser(updated);
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(updated));
      await logAuditEvent('TELEBOT_CHANGE', `Telegram bot config updated (Chat ID: ${chatId})`, currentUser.uid, currentUser.email);
      return { success: true };
    }
    return { success: false, error: 'No active session' };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        firebaseUser,
        isAdmin: currentUser?.role === 'admin',
        isFirebaseActive,
        loading,
        login,
        logout,
        updatePassword,
        updateUserContact,
        updateTeleBot,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
