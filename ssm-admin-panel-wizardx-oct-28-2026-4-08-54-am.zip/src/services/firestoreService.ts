import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/config';
import { Device, Message, FormRecord, AppSettings, AuditLog } from '../types';
import {
  INITIAL_DEVICES,
  INITIAL_MESSAGES,
  INITIAL_OLD_MESSAGES,
  INITIAL_FORM_RECORDS,
  INITIAL_APP_SETTINGS,
  INITIAL_AUDIT_LOGS,
} from '../data/mockData';

// LocalStorage keys for preview/fallback mode
const STORAGE_KEYS = {
  DEVICES: 'ssm_devices_v1',
  MESSAGES: 'ssm_messages_v1',
  OLD_MESSAGES: 'ssm_old_messages_v1',
  FORM_RECORDS: 'ssm_form_records_v1',
  APP_SETTINGS: 'ssm_app_settings_v1',
  AUDIT_LOGS: 'ssm_audit_logs_v1',
};

const getLocal = <T>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
};

const setLocal = <T>(key: string, val: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.error('Failed to save to local storage', e);
  }
};

// --- Devices ---
export const fetchDevices = async (): Promise<Device[]> => {
  if (isFirebaseConfigured() && db) {
    try {
      const colRef = collection(db, 'devices');
      const snap = await getDocs(colRef);
      if (!snap.empty) {
        return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Device));
      }
    } catch (e) {
      console.warn('Firestore fetchDevices failed, falling back to local state:', e);
    }
  }
  return getLocal<Device[]>(STORAGE_KEYS.DEVICES, INITIAL_DEVICES);
};

export const saveDevice = async (device: Device): Promise<Device> => {
  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'devices', device.id);
      await setDoc(docRef, device, { merge: true });
    } catch (e) {
      console.warn('Firestore saveDevice failed, storing locally:', e);
    }
  }
  const current = getLocal<Device[]>(STORAGE_KEYS.DEVICES, INITIAL_DEVICES);
  const exists = current.some((d) => d.id === device.id);
  const updated = exists ? current.map((d) => (d.id === device.id ? device : d)) : [device, ...current];
  setLocal(STORAGE_KEYS.DEVICES, updated);
  return device;
};

export const updateDeviceStatus = async (
  deviceId: string,
  updates: Partial<Device>
): Promise<void> => {
  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'devices', deviceId);
      await updateDoc(docRef, updates);
    } catch (e) {
      console.warn('Firestore updateDeviceStatus error:', e);
    }
  }
  const current = getLocal<Device[]>(STORAGE_KEYS.DEVICES, INITIAL_DEVICES);
  const updated = current.map((d) => (d.id === deviceId || d.deviceId === deviceId ? { ...d, ...updates } : d));
  setLocal(STORAGE_KEYS.DEVICES, updated);
};

// --- Messages ---
export const fetchMessages = async (deviceId?: string, isOld: boolean = false): Promise<Message[]> => {
  const colName = isOld ? 'oldMessages' : 'messages';
  const localKey = isOld ? STORAGE_KEYS.OLD_MESSAGES : STORAGE_KEYS.MESSAGES;
  const initial = isOld ? INITIAL_OLD_MESSAGES : INITIAL_MESSAGES;

  if (isFirebaseConfigured() && db) {
    try {
      const colRef = collection(db, colName);
      let q = query(colRef, orderBy('createdAt', 'desc'), limit(100));
      if (deviceId) {
        q = query(colRef, where('deviceId', '==', deviceId), orderBy('createdAt', 'desc'), limit(100));
      }
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Message));
      }
    } catch (e) {
      console.warn(`Firestore fetchMessages (${colName}) failed, falling back to local:`, e);
    }
  }

  const all = getLocal<Message[]>(localKey, initial);
  if (deviceId) {
    return all.filter((m) => m.deviceId === deviceId);
  }
  return all;
};

export const sendMessageSimulation = async (
  deviceId: string,
  recipientNumber: string,
  body: string,
  simIndex: number = 1
): Promise<Message> => {
  const now = new Date();
  const timeStr = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  
  const newMessage: Message = {
    id: `msg-${Date.now()}`,
    messageId: `${Date.now()}`,
    deviceId,
    ownerUid: 'usr-admin-1',
    senderLabel: `OUT-SIM${simIndex}-${recipientNumber.slice(-4)}`,
    body: `[To: ${recipientNumber}] ${body}`,
    category: 'general',
    createdAt: now.toISOString(),
    timestamp: timeStr,
    isOld: false,
  };

  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'messages', newMessage.id);
      await setDoc(docRef, newMessage);
    } catch (e) {
      console.warn('Firestore sendMessageSimulation failed:', e);
    }
  }

  const current = getLocal<Message[]>(STORAGE_KEYS.MESSAGES, INITIAL_MESSAGES);
  setLocal(STORAGE_KEYS.MESSAGES, [newMessage, ...current]);
  return newMessage;
};

// --- Form Records ---
export const fetchFormRecords = async (deviceId?: string): Promise<FormRecord[]> => {
  if (isFirebaseConfigured() && db) {
    try {
      const colRef = collection(db, 'formRecords');
      let q = query(colRef, orderBy('createdAt', 'desc'));
      if (deviceId) {
        q = query(colRef, where('deviceId', '==', deviceId));
      }
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map((d) => ({ id: d.id, ...d.data() } as FormRecord));
      }
    } catch (e) {
      console.warn('Firestore fetchFormRecords failed, using local records:', e);
    }
  }
  const all = getLocal<FormRecord[]>(STORAGE_KEYS.FORM_RECORDS, INITIAL_FORM_RECORDS);
  if (deviceId) {
    return all.filter((r) => r.deviceId === deviceId);
  }
  return all;
};

export const saveFormRecord = async (record: FormRecord): Promise<void> => {
  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'formRecords', record.id);
      await setDoc(docRef, record);
    } catch (e) {
      console.warn('Firestore saveFormRecord error:', e);
    }
  }
  const current = getLocal<FormRecord[]>(STORAGE_KEYS.FORM_RECORDS, INITIAL_FORM_RECORDS);
  setLocal(STORAGE_KEYS.FORM_RECORDS, [record, ...current]);
};

// --- App Settings ---
export const fetchAppSettings = async (): Promise<AppSettings> => {
  if (isFirebaseConfigured() && db) {
    try {
      const colRef = collection(db, 'appSettings');
      const snap = await getDocs(colRef);
      if (!snap.empty) {
        return snap.docs[0].data() as AppSettings;
      }
    } catch (e) {
      console.warn('Firestore fetchAppSettings failed:', e);
    }
  }
  return getLocal<AppSettings>(STORAGE_KEYS.APP_SETTINGS, INITIAL_APP_SETTINGS);
};

export const updateAppSettings = async (settings: Partial<AppSettings>): Promise<AppSettings> => {
  const current = getLocal<AppSettings>(STORAGE_KEYS.APP_SETTINGS, INITIAL_APP_SETTINGS);
  const updated: AppSettings = {
    ...current,
    ...settings,
    updatedAt: new Date().toISOString(),
  };

  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'appSettings', 'global_config');
      await setDoc(docRef, updated, { merge: true });
    } catch (e) {
      console.warn('Firestore updateAppSettings error:', e);
    }
  }

  setLocal(STORAGE_KEYS.APP_SETTINGS, updated);
  return updated;
};

// --- Audit Logs ---
export const logAuditEvent = async (action: string, details: string, actorUid: string = 'usr-admin-1', actorEmail?: string): Promise<void> => {
  const newLog: AuditLog = {
    id: `log-${Date.now()}`,
    actorUid,
    actorEmail: actorEmail || 'admin@wizardx.panel',
    action,
    details,
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
  };

  if (isFirebaseConfigured() && db) {
    try {
      const docRef = doc(db, 'auditLogs', newLog.id);
      await setDoc(docRef, newLog);
    } catch (e) {
      console.warn('Firestore logAuditEvent failed:', e);
    }
  }

  const logs = getLocal<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  setLocal(STORAGE_KEYS.AUDIT_LOGS, [newLog, ...logs.slice(0, 99)]);
};

export const fetchAuditLogs = async (): Promise<AuditLog[]> => {
  if (isFirebaseConfigured() && db) {
    try {
      const colRef = collection(db, 'auditLogs');
      const q = query(colRef, orderBy('timestamp', 'desc'), limit(50));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map((d) => ({ id: d.id, ...d.data() } as AuditLog));
      }
    } catch (e) {
      console.warn('Firestore fetchAuditLogs error:', e);
    }
  }
  return getLocal<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
};

// One-click Firestore Seeder for quick deployment verification
export const seedFirestore = async (): Promise<{ success: boolean; message: string }> => {
  if (!isFirebaseConfigured() || !db) {
    return {
      success: false,
      message: 'Firebase is not configured in .env. Enter valid VITE_FIREBASE_* keys to seed remote Firestore.',
    };
  }

  try {
    for (const d of INITIAL_DEVICES) {
      await setDoc(doc(db, 'devices', d.id), d);
    }
    for (const m of INITIAL_MESSAGES) {
      await setDoc(doc(db, 'messages', m.id), m);
    }
    for (const m of INITIAL_OLD_MESSAGES) {
      await setDoc(doc(db, 'oldMessages', m.id), m);
    }
    for (const f of INITIAL_FORM_RECORDS) {
      await setDoc(doc(db, 'formRecords', f.id), f);
    }
    await setDoc(doc(db, 'appSettings', 'global_config'), INITIAL_APP_SETTINGS);
    
    await logAuditEvent('FIRESTORE_SEED', 'Initial seed collections populated into Firestore', 'system', 'system@wizardx');
    return {
      success: true,
      message: 'Successfully seeded devices, messages, form records, and settings into Cloud Firestore!',
    };
  } catch (error: any) {
    return {
      success: false,
      message: error?.message || 'Failed to seed Firestore collections.',
    };
  }
};
