import React from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onSearchSubmit?: () => void;
  placeholder?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchTerm,
  onSearchChange,
  onSearchSubmit,
  placeholder = 'Enter Number To Seach',
}) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchSubmit) onSearchSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="w-full mb-3.5 relative">
      <div className="relative flex items-center bg-white rounded-full shadow-[0_2px_12px_rgba(0,0,0,0.04)] border border-gray-100/90 pl-5 pr-2 py-1.5 transition-shadow hover:shadow-[0_4px_16px_rgba(0,0,0,0.06)] focus-within:ring-2 focus-within:ring-[#315FEA]/20">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-transparent text-sm sm:text-base font-medium text-[#202124] placeholder:text-gray-400 placeholder:font-normal focus:outline-none"
        />

        {searchTerm && (
          <button
            type="button"
            onClick={() => onSearchChange('')}
            className="p-1 mr-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <button
          type="submit"
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#315FEA] text-white flex items-center justify-center hover:bg-[#254cc4] active:scale-95 transition-all shadow-sm shrink-0 focus:outline-none"
          title="Search"
        >
          <Search className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
        </button>
      </div>
    </form>
  );
};
