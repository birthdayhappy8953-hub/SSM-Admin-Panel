import React, { useState } from 'react';
import { Message, Device } from '../types';
import { FourSquaresLogo, DemonIcon } from './Icons';
import { Mail, ArrowLeft, Copy, Check, Search } from 'lucide-react';

interface MessagesViewProps {
  device?: Device | null;
  messages: Message[];
  isOldMessages?: boolean;
  onBack: () => void;
  onShowFormData: () => void;
  onOpenSendSms: () => void;
  onOpenSettings: () => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  device,
  messages,
  isOldMessages = false,
  onBack,
  onShowFormData,
  onOpenSendSms,
  onOpenSettings,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredMessages = messages.filter((m) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      m.senderLabel.toLowerCase().includes(term) ||
      m.body.toLowerCase().includes(term) ||
      m.timestamp.toLowerCase().includes(term)
    );
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full">
      {/* Top Header matching Screenshot 2 */}
      <div className="w-full bg-white rounded-2xl md:rounded-3xl shadow-[0_2px_12px_rgba(0,0,0,0.04)] px-4 py-3 mb-3 flex items-center justify-between border border-gray-100/80">
        {/* Left: App Logo or Back Arrow */}
        <div className="flex items-center space-x-2">
          <FourSquaresLogo className="w-7 h-7 sm:w-8 sm:h-8" onClick={onBack} />
          <button
            onClick={onBack}
            className="p-1 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        {/* Center: Title */}
        <div className="flex flex-col items-center">
          <h1 className="text-base sm:text-lg font-bold text-[#202124] tracking-tight">
            {isOldMessages ? 'Old Messages' : 'Messages'}
          </h1>
          {device && (
            <span className="text-[11px] text-[#8A8A8A] font-medium">
              ID {device.deviceId} • {device.displayName}
            </span>
          )}
        </div>

        {/* Right: Demon and Circular Envelope */}
        <div className="flex items-center space-x-2.5">
          <DemonIcon className="w-7 h-7" onClick={onOpenSettings} />
          <button
            onClick={onOpenSendSms}
            title="Compose SMS"
            className="w-8 h-8 rounded-full bg-[#315FEA] text-white flex items-center justify-center hover:bg-[#254cc4] active:scale-95 transition-all shadow-sm focus:outline-none"
          >
            <Mail className="w-4 h-4 fill-white" />
          </button>
        </div>
      </div>

      {/* Full-width Black Button "Show Form Data" matching Screenshot 2 */}
      <button
        type="button"
        onClick={onShowFormData}
        className="w-full bg-[#050505] hover:bg-[#1a1a1a] active:scale-[0.99] text-white font-bold py-3.5 px-4 rounded-[18px] text-sm tracking-wide shadow-md transition-all mb-3.5 focus:outline-none"
      >
        Show Form Data
      </button>

      {/* Optional Search / Filter for Messages */}
      <div className="relative mb-3">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter messages or sender..."
          className="w-full bg-white rounded-full py-2 pl-9 pr-4 text-xs font-medium text-gray-700 placeholder:text-gray-400 border border-gray-200/80 shadow-sm focus:outline-none focus:ring-2 focus:ring-[#315FEA]/20"
        />
        <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
      </div>

      {/* Messages List matching Screenshot 2 */}
      {filteredMessages.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-gray-100 shadow-sm">
          <Mail className="w-10 h-10 text-gray-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-gray-700">No messages found</p>
          <p className="text-xs text-gray-400 mt-1">There are no message records for this device or filter.</p>
        </div>
      ) : (
        <div className="space-y-3 pb-6">
          {filteredMessages.map((msg) => (
            <div
              key={msg.id}
              className="bg-white rounded-[22px] p-4 shadow-[0_2px_12px_rgba(0,0,0,0.03)] border border-gray-100/90 hover:shadow-[0_4px_16px_rgba(0,0,0,0.06)] transition-all"
            >
              {/* Header Strip: Black Bar with Sender Label */}
              <div className="bg-[#050505] text-white font-bold text-xs sm:text-sm px-3.5 py-1.5 rounded-lg inline-block mb-3 tracking-wide">
                {msg.senderLabel}
              </div>

              {/* Message Body */}
              <div className="text-sm text-[#202124] leading-relaxed break-words font-normal whitespace-pre-wrap">
                {msg.body}
              </div>

              {/* Bottom Row: Copy action & Timestamp (aligned to bottom-right as in screenshot) */}
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-50">
                <button
                  onClick={() => handleCopy(msg.id, msg.body)}
                  className="inline-flex items-center space-x-1 text-[11px] text-gray-400 hover:text-[#315FEA] font-medium transition-colors"
                  title="Copy message content"
                >
                  {copiedId === msg.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="text-emerald-500">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>

                <div className="text-[11px] text-[#8A8A8A] font-medium tracking-tight">
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
