import React from 'react';

// 4-Blue-Squares Application Logo (from screenshots)
export const FourSquaresLogo: React.FC<{ className?: string; onClick?: () => void }> = ({
  className = 'w-9 h-9',
  onClick,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`grid grid-cols-2 gap-1 p-0.5 cursor-pointer rounded-lg hover:opacity-90 transition-opacity focus:outline-none ${className}`}
      title="Dashboard Home"
    >
      <span className="bg-[#315FEA] rounded-md w-full h-full block min-h-[14px]"></span>
      <span className="bg-[#315FEA] rounded-md w-full h-full block min-h-[14px]"></span>
      <span className="bg-[#315FEA] rounded-md w-full h-full block min-h-[14px]"></span>
      <span className="bg-[#315FEA] rounded-md w-full h-full block min-h-[14px]"></span>
    </button>
  );
};

// Red Devil / Demon Icon (prominently seen in all reference screenshots)
export const DemonIcon: React.FC<{ className?: string; onClick?: () => void }> = ({
  className = 'w-7 h-7',
  onClick,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative inline-flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95 focus:outline-none ${className}`}
      title="Device Actions & Settings"
    >
      <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-sm">
        {/* Head */}
        <circle cx="20" cy="22" r="14" fill="#E53935" />
        {/* Horns */}
        <path d="M11 14C9 8 5 9 6 6C10 5 13 11 14 13" fill="#D32F2F" />
        <path d="M29 14C31 8 35 9 34 6C30 5 27 11 26 13" fill="#D32F2F" />
        {/* Eyes (mischievous diagonal) */}
        <ellipse cx="15.5" cy="19.5" rx="2.5" ry="3.5" transform="rotate(-15 15.5 19.5)" fill="#1F1F1F" />
        <ellipse cx="24.5" cy="19.5" rx="2.5" ry="3.5" transform="rotate(15 24.5 19.5)" fill="#1F1F1F" />
        {/* Smile with subtle fangs */}
        <path
          d="M14 26C16 30 24 30 26 26"
          stroke="#1F1F1F"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </svg>
    </button>
  );
};

// Device Smartphone Thumbnail (colorful modern smartphone mockup matching the screenshots)
export const DevicePhoneGraphic: React.FC<{ className?: string }> = ({ className = 'w-11 h-18' }) => {
  return (
    <div
      className={`relative rounded-xl p-[2px] bg-[#1E1E1E] shadow-md flex flex-col items-center justify-between overflow-hidden shrink-0 ${className}`}
      style={{ aspectRatio: '9/19' }}
    >
      {/* Speaker notch */}
      <div className="w-4 h-1 bg-[#2C2C2C] rounded-full mt-0.5 z-10"></div>
      
      {/* Screen wallpaper (matches geometric colorful wallpaper from screenshots) */}
      <div className="absolute inset-[2.5px] rounded-lg overflow-hidden bg-slate-900 flex flex-col">
        {/* Colorful wallpaper shapes */}
        <div className="h-1/2 w-full bg-gradient-to-br from-emerald-500 via-yellow-500 to-amber-600"></div>
        <div className="h-1/2 w-full bg-gradient-to-tr from-rose-600 via-indigo-600 to-sky-400"></div>
        {/* Bottom bar indicator */}
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-white/80 rounded-full"></div>
      </div>

      {/* Camera dot */}
      <div className="w-1.5 h-1.5 rounded-full bg-black/60 z-10 self-center mb-1"></div>
    </div>
  );
};
