import React from 'react';
import { Device } from '../types';
import { DevicePhoneGraphic, DemonIcon } from './Icons';
import { MessageSquare, Mail, Wifi, WifiOff } from 'lucide-react';

interface DeviceCardProps {
  device: Device;
  onViewMessages: (device: Device) => void;
  onViewOldMessages: (device: Device) => void;
  onOpenSendSms: (device: Device) => void;
  onOpenSimActions: (device: Device) => void;
  onCardActionMenu: (device: Device) => void;
}

export const DeviceCard: React.FC<DeviceCardProps> = ({
  device,
  onViewMessages,
  onViewOldMessages,
  onOpenSendSms,
  onOpenSimActions,
  onCardActionMenu,
}) => {
  const isOnline = device.networkStatus === 'connected';

  return (
    <div className="w-full bg-white rounded-[22px] p-3 sm:p-4 shadow-[0_2px_12px_rgba(0,0,0,0.04)] border border-gray-100/90 mb-3 transition-all hover:shadow-[0_6px_20px_rgba(0,0,0,0.06)]">
      {/* Top Section */}
      <div className="flex items-start justify-between gap-2.5 sm:gap-3.5 mb-3.5">
        {/* Left: Phone Mockup Thumbnail */}
        <div
          onClick={() => onOpenSimActions(device)}
          className="cursor-pointer hover:opacity-90 transition-opacity"
          title="Click to manage SIM & Forwarding"
        >
          <DevicePhoneGraphic className="w-10 sm:w-11" />
        </div>

        {/* Center: Device Info */}
        <div className="flex-1 min-w-0 pt-0.5">
          <div className="flex items-center space-x-2 mb-1">
            <span className="bg-[#050505] text-white text-[11px] sm:text-xs font-bold px-2 py-0.5 rounded-full shrink-0">
              {device.deviceId}
            </span>
            <span className="font-bold text-sm sm:text-base text-[#202124] truncate">
              {device.displayName}
            </span>
          </div>

          <div className="text-xs text-[#8A8A8A] font-medium leading-relaxed truncate">
            {device.connectionStatus}
          </div>

          <div className="text-xs text-[#8A8A8A] font-medium mt-0.5">
            Battery {device.batteryPercentage}%
          </div>
        </div>

        {/* Right: Network & Demon Icons */}
        <div className="flex flex-col items-end space-y-2 shrink-0 pt-0.5">
          {/* Wi-Fi Icon */}
          <div title={isOnline ? 'Network: Connected' : 'Network: Disconnected'}>
            {isOnline ? (
              <Wifi className="w-5 h-5 text-emerald-500 stroke-[2.5]" />
            ) : (
              <div className="relative text-rose-500">
                <WifiOff className="w-5 h-5 stroke-[2.5]" />
              </div>
            )}
          </div>

          {/* Demon Icon */}
          <DemonIcon className="w-6 h-6" onClick={() => onCardActionMenu(device)} />
        </div>
      </div>

      {/* Bottom Action Buttons */}
      <div className="flex items-center space-x-2">
        {/* Old Messages Button */}
        <button
          onClick={() => onViewOldMessages(device)}
          className="flex-1 flex items-center justify-center space-x-1.5 bg-[#315FEA] hover:bg-[#254cc4] active:scale-[0.98] text-white text-xs sm:text-sm font-semibold py-2 px-3 rounded-full shadow-sm transition-all focus:outline-none"
        >
          <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <MessageSquare className="w-3 h-3 text-white fill-white" />
          </div>
          <span className="truncate">Old Messages</span>
        </button>

        {/* Messages Button */}
        <button
          onClick={() => onViewMessages(device)}
          className="flex-1 flex items-center justify-center space-x-1.5 bg-[#315FEA] hover:bg-[#254cc4] active:scale-[0.98] text-white text-xs sm:text-sm font-semibold py-2 px-3 rounded-full shadow-sm transition-all focus:outline-none"
        >
          <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <MessageSquare className="w-3 h-3 text-white" />
          </div>
          <span className="truncate">Messages</span>
        </button>

        {/* Circular Envelope Quick Action Button */}
        <button
          onClick={() => onOpenSendSms(device)}
          title="Send SMS / Manage SIM"
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#315FEA] hover:bg-[#254cc4] active:scale-95 text-white flex items-center justify-center shrink-0 shadow-sm transition-all focus:outline-none"
        >
          <Mail className="w-4 h-4 fill-white" />
        </button>
      </div>
    </div>
  );
};
