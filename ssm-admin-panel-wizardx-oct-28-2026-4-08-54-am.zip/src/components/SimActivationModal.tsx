import React, { useState } from 'react';
import { Device } from '../types';
import { X, CheckCircle2, AlertCircle } from 'lucide-react';
import { updateDeviceStatus, logAuditEvent } from '../services/firestoreService';

interface SimActivationModalProps {
  isOpen: boolean;
  onClose: () => void;
  device: Device | null;
  onDeviceUpdated?: (updated: Device) => void;
}

export const SimActivationModal: React.FC<SimActivationModalProps> = ({
  isOpen,
  onClose,
  device,
  onDeviceUpdated,
}) => {
  const [selectedSim, setSelectedSim] = useState<1 | 2>(device?.selectedSim || 1);
  const [targetNumber, setTargetNumber] = useState<string>(device?.forwardingNumber || '');
  const [statusFeedback, setStatusFeedback] = useState<{ type: 'info' | 'success' | 'warn'; msg: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !device) return null;

  const handleActivate = async () => {
    if (!targetNumber.trim()) {
      setStatusFeedback({ type: 'warn', msg: 'Please enter a target destination number.' });
      return;
    }
    setIsProcessing(true);
    setStatusFeedback({ type: 'info', msg: 'Sending activation sequence to SIM...' });

    setTimeout(async () => {
      const updated: Device = {
        ...device,
        selectedSim,
        forwardingNumber: targetNumber.trim(),
        isForwardingActive: true,
        connectionStatus: `${targetNumber.trim()} , secure`,
        updatedAt: new Date().toISOString(),
      };
      await updateDeviceStatus(device.id, updated);
      await logAuditEvent('SIM_ACTIVATION', `Activated forwarding to ${targetNumber} on SIM ${selectedSim} for device ${device.deviceId}`);
      if (onDeviceUpdated) onDeviceUpdated(updated);
      setIsProcessing(false);
      setStatusFeedback({
        type: 'success',
        msg: `SIM ${selectedSim} successfully activated with forwarding to ${targetNumber}.`,
      });
    }, 800);
  };

  const handleDeactivate = async () => {
    setIsProcessing(true);
    setStatusFeedback({ type: 'info', msg: 'Deactivating forward rules...' });

    setTimeout(async () => {
      const updated: Device = {
        ...device,
        isForwardingActive: false,
        forwardingNumber: '',
        connectionStatus: 'secure , not available',
        updatedAt: new Date().toISOString(),
      };
      await updateDeviceStatus(device.id, updated);
      await logAuditEvent('SIM_DEACTIVATE', `Deactivated forwarding on device ${device.deviceId}`);
      if (onDeviceUpdated) onDeviceUpdated(updated);
      setIsProcessing(false);
      setStatusFeedback({
        type: 'success',
        msg: `SIM forwarding has been deactivated successfully.`,
      });
    }, 700);
  };

  const handleCheckActivation = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      if (device.isForwardingActive && device.forwardingNumber) {
        setStatusFeedback({
          type: 'success',
          msg: `ACTIVE: SIM ${selectedSim} is actively routed to ${device.forwardingNumber}.`,
        });
      } else {
        setStatusFeedback({
          type: 'warn',
          msg: `INACTIVE: No active forwarding rules detected on SIM ${selectedSim}.`,
        });
      }
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm sm:max-w-md bg-white rounded-[28px] p-6 shadow-2xl border border-gray-100 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4">
          <h2 className="text-base font-bold text-[#202124]">
            SIM Management • Device {device.deviceId}
          </h2>
          <p className="text-xs text-gray-400">
            {device.displayName} ({device.phoneNumber || device.sim1Number})
          </p>
        </div>

        {/* Status Alert */}
        {statusFeedback && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center space-x-2 mb-3.5 ${
              statusFeedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : statusFeedback.type === 'warn'
                ? 'bg-amber-50 text-amber-700 border border-amber-200'
                : 'bg-blue-50 text-blue-700 border border-blue-200'
            }`}
          >
            {statusFeedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{statusFeedback.msg}</span>
          </div>
        )}

        {/* 2 Blue SIM Cards matching Screenshot 4 */}
        <div className="space-y-2.5 mb-4">
          {/* SIM 1 Card */}
          <div
            onClick={() => setSelectedSim(1)}
            className={`w-full rounded-2xl p-4 text-white cursor-pointer transition-all flex items-center space-x-3.5 ${
              selectedSim === 1
                ? 'bg-[#315FEA] shadow-md ring-2 ring-[#315FEA]/50'
                : 'bg-[#4B69E8]/80 hover:bg-[#4B69E8]'
            }`}
          >
            {/* Radio indicator */}
            <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shrink-0">
              {selectedSim === 1 && <div className="w-3 h-3 rounded-full bg-white"></div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm sm:text-base tracking-wide truncate">
                {device.sim1Number || '8839803911'}
              </div>
              <div className="text-xs text-white/90 font-medium">
                {device.sim1Carrier || 'airtel'}
              </div>
            </div>
          </div>

          {/* SIM 2 Card */}
          <div
            onClick={() => setSelectedSim(2)}
            className={`w-full rounded-2xl p-4 text-white cursor-pointer transition-all flex items-center space-x-3.5 ${
              selectedSim === 2
                ? 'bg-[#315FEA] shadow-md ring-2 ring-[#315FEA]/50'
                : 'bg-[#4B69E8]/80 hover:bg-[#4B69E8]'
            }`}
          >
            {/* Radio indicator */}
            <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shrink-0">
              {selectedSim === 2 && <div className="w-3 h-3 rounded-full bg-white"></div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm sm:text-base tracking-wide truncate">
                {device.sim2Number || 'not available'}
              </div>
              <div className="text-xs text-white/90 font-medium">
                {device.sim2Carrier || 'not available'}
              </div>
            </div>
          </div>
        </div>

        {/* Number Input matching Screenshot 4 */}
        <div className="mb-4">
          <input
            type="text"
            value={targetNumber}
            onChange={(e) => setTargetNumber(e.target.value)}
            placeholder="Number"
            className="w-full bg-white border-2 border-gray-300 focus:border-[#315FEA] rounded-2xl px-4 py-3 text-sm font-medium text-[#202124] placeholder:text-gray-400 focus:outline-none transition-colors"
          />
        </div>

        {/* ACTIVATE Button matching Screenshot 4 */}
        <button
          type="button"
          onClick={handleActivate}
          disabled={isProcessing}
          className="w-full bg-[#050505] hover:bg-[#1a1a1a] active:scale-[0.99] text-white font-bold py-3.5 px-4 rounded-2xl text-xs sm:text-sm tracking-wider shadow-md transition-all mb-2.5 focus:outline-none disabled:opacity-50"
        >
          {isProcessing ? 'PROCESSING...' : 'ACTIVATE'}
        </button>

        {/* DEACTIVATE and CHECK ACTIVATION Buttons side-by-side matching Screenshot 4 */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={handleDeactivate}
            disabled={isProcessing}
            className="w-full bg-[#050505] hover:bg-[#1a1a1a] active:scale-[0.99] text-white font-bold py-3.5 px-2 rounded-2xl text-[11px] sm:text-xs tracking-wider shadow-md transition-all focus:outline-none disabled:opacity-50 truncate"
          >
            DEACTIVATE
          </button>

          <button
            type="button"
            onClick={handleCheckActivation}
            disabled={isProcessing}
            className="w-full bg-[#050505] hover:bg-[#1a1a1a] active:scale-[0.99] text-white font-bold py-3.5 px-2 rounded-2xl text-[11px] sm:text-xs tracking-wider shadow-md transition-all focus:outline-none disabled:opacity-50 truncate"
          >
            CHECK ACTIVATION
          </button>
        </div>
      </div>
    </div>
  );
};
