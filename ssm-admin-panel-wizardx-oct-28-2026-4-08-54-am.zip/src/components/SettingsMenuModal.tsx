import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Lock,
  Phone,
  Send,
  User,
  LogOut,
  X,
  Check,
  AlertCircle,
  Copy,
  ChevronLeft,
} from 'lucide-react';

interface SettingsMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId?: string;
}

type ActiveSubView = 'menu' | 'password' | 'number' | 'telebot' | 'contact';

export const SettingsMenuModal: React.FC<SettingsMenuModalProps> = ({
  isOpen,
  onClose,
  userId = 'id41',
}) => {
  const { currentUser, logout, updatePassword, updateUserContact, updateTeleBot } = useAuth();
  const [subView, setSubView] = useState<ActiveSubView>('menu');

  // Subform states
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [contactNumber, setContactNumber] = useState(currentUser?.contactNumber || '+91 8839803911');
  const [botToken, setBotToken] = useState(currentUser?.telegramBotToken || '');
  const [chatId, setChatId] = useState(currentUser?.telegramChatId || '');

  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedContact, setCopiedContact] = useState(false);

  if (!isOpen) return null;

  const handleClose = () => {
    setSubView('menu');
    setStatusMsg(null);
    onClose();
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setStatusMsg({ type: 'error', text: 'Passwords do not match.' });
      return;
    }
    setIsSubmitting(true);
    setStatusMsg(null);
    const res = await updatePassword(newPassword);
    setIsSubmitting(false);
    if (res.success) {
      setStatusMsg({ type: 'success', text: 'Password successfully changed!' });
      setTimeout(() => {
        setSubView('menu');
        setNewPassword('');
        setConfirmPassword('');
        setStatusMsg(null);
      }, 1500);
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Failed to change password.' });
    }
  };

  const handleNumberSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMsg(null);
    const res = await updateUserContact(contactNumber);
    setIsSubmitting(false);
    if (res.success) {
      setStatusMsg({ type: 'success', text: 'Contact number updated successfully!' });
      setTimeout(() => {
        setSubView('menu');
        setStatusMsg(null);
      }, 1500);
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Failed to update number.' });
    }
  };

  const handleTeleBotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMsg(null);
    const res = await updateTeleBot(botToken, chatId);
    setIsSubmitting(false);
    if (res.success) {
      setStatusMsg({ type: 'success', text: 'TeleBot notifications configured!' });
      setTimeout(() => {
        setSubView('menu');
        setStatusMsg(null);
      }, 1500);
    } else {
      setStatusMsg({ type: 'error', text: res.error || 'Failed to update TeleBot settings.' });
    }
  };

  const handleLogout = async () => {
    await logout();
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm bg-white rounded-[28px] p-6 shadow-2xl border border-gray-100 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Back button if in subview */}
        {subView !== 'menu' && (
          <button
            onClick={() => {
              setSubView('menu');
              setStatusMsg(null);
            }}
            className="flex items-center space-x-1 text-xs font-semibold text-gray-500 hover:text-gray-800 mb-3"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back to Menu</span>
          </button>
        )}

        {/* Header: id41 matching Screenshot 3 */}
        <div className="mb-4">
          <h2 className="text-lg font-bold text-[#202124] tracking-tight">
            {subView === 'menu' ? (
              <span className="font-mono">{currentUser?.displayName || userId}</span>
            ) : subView === 'password' ? (
              'Change Password'
            ) : subView === 'number' ? (
              'Change Number'
            ) : subView === 'telebot' ? (
              'Change TeleBot'
            ) : (
              'Contact Admin'
            )}
          </h2>
          <p className="text-xs text-gray-400">
            {subView === 'menu' ? 'Account Preferences & Actions' : 'Enter requested details below'}
          </p>
        </div>

        {/* Status Message */}
        {statusMsg && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center space-x-2 mb-4 ${
              statusMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-rose-50 text-rose-700 border border-rose-200'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <Check className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            )}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* 1. Main Menu View matching Screenshot 3 */}
        {subView === 'menu' && (
          <div className="space-y-3">
            {/* 1. Change Password */}
            <button
              onClick={() => setSubView('password')}
              className="w-full bg-[#2A2B2E] hover:bg-[#1E1F21] active:scale-[0.98] text-white font-semibold py-3 px-4 rounded-full flex items-center space-x-3.5 transition-all shadow-sm focus:outline-none"
            >
              <div className="w-8 h-8 rounded-full bg-[#00A3FF] flex items-center justify-center shrink-0 shadow-sm">
                <Lock className="w-4 h-4 text-white stroke-[2.5]" />
              </div>
              <span className="text-sm font-medium">Change Password</span>
            </button>

            {/* 2. Change Number */}
            <button
              onClick={() => setSubView('number')}
              className="w-full bg-[#2A2B2E] hover:bg-[#1E1F21] active:scale-[0.98] text-white font-semibold py-3 px-4 rounded-full flex items-center space-x-3.5 transition-all shadow-sm focus:outline-none"
            >
              <div className="w-8 h-8 rounded-full bg-[#00A3FF] flex items-center justify-center shrink-0 shadow-sm">
                <Phone className="w-4 h-4 text-white stroke-[2.5]" />
              </div>
              <span className="text-sm font-medium">Change Number</span>
            </button>

            {/* 3. Change TeleBot */}
            <button
              onClick={() => setSubView('telebot')}
              className="w-full bg-[#2A2B2E] hover:bg-[#1E1F21] active:scale-[0.98] text-white font-semibold py-3 px-4 rounded-full flex items-center space-x-3.5 transition-all shadow-sm focus:outline-none"
            >
              <div className="w-8 h-8 rounded-full bg-[#00A3FF] flex items-center justify-center shrink-0 shadow-sm">
                <Send className="w-4 h-4 text-white stroke-[2.5]" />
              </div>
              <span className="text-sm font-medium">Change TeleBot</span>
            </button>

            {/* 4. Contact Admin */}
            <button
              onClick={() => setSubView('contact')}
              className="w-full bg-[#2A2B2E] hover:bg-[#1E1F21] active:scale-[0.98] text-white font-semibold py-3 px-4 rounded-full flex items-center space-x-3.5 transition-all shadow-sm focus:outline-none"
            >
              <div className="w-8 h-8 rounded-full bg-[#4FC3F7] flex items-center justify-center shrink-0 shadow-sm">
                <User className="w-4 h-4 text-white stroke-[2.5]" />
              </div>
              <span className="text-sm font-medium">Contact Admin</span>
            </button>

            {/* 5. Identity Logout */}
            <button
              onClick={handleLogout}
              className="w-full bg-[#2A2B2E] hover:bg-[#1E1F21] active:scale-[0.98] text-white font-semibold py-3 px-4 rounded-full flex items-center space-x-3.5 transition-all shadow-sm focus:outline-none"
            >
              <div className="w-8 h-8 rounded-full bg-[#EF5350] flex items-center justify-center shrink-0 shadow-sm">
                <LogOut className="w-4 h-4 text-white stroke-[2.5]" />
              </div>
              <span className="text-sm font-medium">Identity Logout</span>
            </button>
          </div>
        )}

        {/* 2. Change Password Subview */}
        {subView === 'password' && (
          <form onSubmit={handlePasswordSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">New Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#315FEA]/30"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Confirm New Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#315FEA]/30"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#050505] hover:bg-[#202020] text-white font-bold py-3 rounded-full text-sm transition-all shadow-md mt-2 disabled:opacity-50"
            >
              {isSubmitting ? 'Updating...' : 'Save New Password'}
            </button>
          </form>
        )}

        {/* 3. Change Number Subview */}
        {subView === 'number' && (
          <form onSubmit={handleNumberSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Verified Mobile Number</label>
              <input
                type="text"
                required
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="+91 8839803911"
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#315FEA]/30 font-mono"
              />
            </div>
            <p className="text-[11px] text-gray-400">
              This number is authorized for account alerts, 2FA, and administrator recovery.
            </p>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#050505] hover:bg-[#202020] text-white font-bold py-3 rounded-full text-sm transition-all shadow-md mt-2 disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : 'Update Phone Number'}
            </button>
          </form>
        )}

        {/* 4. Change TeleBot Subview */}
        {subView === 'telebot' && (
          <form onSubmit={handleTeleBotSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Telegram Bot Token</label>
              <input
                type="text"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder="123456789:ABCDefghIJKLmnOPQRst"
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#315FEA]/30"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Target Chat ID / Group ID</label>
              <input
                type="text"
                value={chatId}
                onChange={(e) => setChatId(e.target.value)}
                placeholder="-100123456789"
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#315FEA]/30"
              />
            </div>
            <p className="text-[11px] text-gray-400">
              When configured, newly authorized messages and form records can dispatch alerts to this Telegram bot.
            </p>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#050505] hover:bg-[#202020] text-white font-bold py-3 rounded-full text-sm transition-all shadow-md mt-2 disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : 'Save TeleBot Configuration'}
            </button>
          </form>
        )}

        {/* 5. Contact Admin Subview */}
        {subView === 'contact' && (
          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-100 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-medium">Support Hotline</span>
                <span className="font-mono font-bold text-gray-800">+91 8839803911</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-medium">Telegram</span>
                <span className="font-mono font-bold text-[#315FEA]">@WizardX_Admin</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-medium">Email Desk</span>
                <span className="font-mono text-gray-800">support@ssmpanel.cloud</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-medium">Support Hours</span>
                <span className="text-emerald-600 font-bold">24x7 Priority</span>
              </div>
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText('+91 8839803911');
                setCopiedContact(true);
                setTimeout(() => setCopiedContact(false), 2000);
              }}
              className="w-full bg-[#050505] hover:bg-[#202020] text-white font-bold py-3 rounded-full text-sm flex items-center justify-center space-x-2 transition-all shadow-md"
            >
              {copiedContact ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Number Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Support Number</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
