import React, { useState } from 'react';
import { Device, Message } from '../types';
import { X, CheckCircle2, AlertCircle } from 'lucide-react';
import { sendMessageSimulation, logAuditEvent } from '../services/firestoreService';

interface SendSmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  device: Device | null;
  onMessageSent?: (msg: Message) => void;
}

export const SendSmsModal: React.FC<SendSmsModalProps> = ({
  isOpen,
  onClose,
  device,
  onMessageSent,
}) => {
  const [selectedSim, setSelectedSim] = useState<1 | 2>(device?.selectedSim || 1);
  const [address, setAddress] = useState('');
  const [messageText, setMessageText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen || !device) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.trim()) {
      setFeedback({ type: 'error', text: 'Please enter a recipient number in "Address here".' });
      return;
    }
    if (!messageText.trim()) {
      setFeedback({ type: 'error', text: 'Please enter a message body.' });
      return;
    }

    setIsSending(true);
    setFeedback(null);

    try {
      const newMsg = await sendMessageSimulation(device.deviceId, address.trim(), messageText.trim(), selectedSim);
      await logAuditEvent('SEND_SMS', `Sent SMS from SIM ${selectedSim} to ${address}: "${messageText.slice(0, 30)}..."`);
      
      if (onMessageSent) {
        onMessageSent(newMsg);
      }

      setIsSending(false);
      setFeedback({ type: 'success', text: 'SMS dispatched successfully!' });
      setTimeout(() => {
        setAddress('');
        setMessageText('');
        setFeedback(null);
        onClose();
      }, 1200);
    } catch (err: any) {
      setIsSending(false);
      setFeedback({ type: 'error', text: err?.message || 'Failed to send SMS.' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm sm:max-w-md bg-white rounded-[28px] p-6 shadow-2xl border border-gray-100 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4">
          <h2 className="text-base font-bold text-[#202124]">
            Compose SMS • Device {device.deviceId}
          </h2>
          <p className="text-xs text-gray-400">{device.displayName}</p>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center space-x-2 mb-3.5 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-rose-50 text-rose-700 border border-rose-200'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            )}
            <span>{feedback.text}</span>
          </div>
        )}

        {/* 2 Blue SIM Selection Cards matching Screenshot 6 */}
        <div className="space-y-2.5 mb-4">
          {/* SIM 1 */}
          <div
            onClick={() => setSelectedSim(1)}
            className={`w-full rounded-2xl p-4 text-white cursor-pointer transition-all flex items-center space-x-3.5 ${
              selectedSim === 1
                ? 'bg-[#315FEA] shadow-md ring-2 ring-[#315FEA]/50'
                : 'bg-[#4B69E8]/80 hover:bg-[#4B69E8]'
            }`}
          >
            <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shrink-0">
              {selectedSim === 1 && <div className="w-3 h-3 rounded-full bg-white"></div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm sm:text-base tracking-wide truncate">
                {device.sim1Number || '8839803911'}
              </div>
              <div className="text-xs text-white/90 font-medium">
                {device.sim1Carrier || 'airtel'}
              </div>
            </div>
          </div>

          {/* SIM 2 */}
          <div
            onClick={() => setSelectedSim(2)}
            className={`w-full rounded-2xl p-4 text-white cursor-pointer transition-all flex items-center space-x-3.5 ${
              selectedSim === 2
                ? 'bg-[#315FEA] shadow-md ring-2 ring-[#315FEA]/50'
                : 'bg-[#4B69E8]/80 hover:bg-[#4B69E8]'
            }`}
          >
            <div className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shrink-0">
              {selectedSim === 2 && <div className="w-3 h-3 rounded-full bg-white"></div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm sm:text-base tracking-wide truncate">
                {device.sim2Number || 'not available'}
              </div>
              <div className="text-xs text-white/90 font-medium">
                {device.sim2Carrier || 'not available'}
              </div>
            </div>
          </div>
        </div>

        {/* Form Inputs matching Screenshot 6 */}
        <form onSubmit={handleSend} className="space-y-3">
          {/* Address here */}
          <div>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Address here"
              className="w-full bg-white border-2 border-gray-300 focus:border-[#315FEA] rounded-2xl px-4 py-3 text-sm font-medium text-[#202124] placeholder:text-gray-400 focus:outline-none transition-colors"
            />
          </div>

          {/* Message here */}
          <div>
            <textarea
              required
              rows={3}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Message here"
              className="w-full bg-white border-2 border-gray-300 focus:border-[#315FEA] rounded-2xl px-4 py-3 text-sm font-medium text-[#202124] placeholder:text-gray-400 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* SEND SMS Button matching Screenshot 6 */}
          <button
            type="submit"
            disabled={isSending}
            className="w-full bg-[#050505] hover:bg-[#1a1a1a] active:scale-[0.99] text-white font-bold py-3.5 px-4 rounded-2xl text-xs sm:text-sm tracking-wider shadow-md transition-all mt-2 focus:outline-none disabled:opacity-50"
          >
            {isSending ? 'DISPATCHING...' : 'SEND SMS'}
          </button>
        </form>
      </div>
    </div>
  );
};
