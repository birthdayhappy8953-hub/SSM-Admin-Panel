import React, { useState } from 'react';
import { FormRecord } from '../types';
import { X, Copy, Check, ChevronLeft, ChevronRight, Eye, EyeOff } from 'lucide-react';

interface FormDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: FormRecord[];
}

export const FormDataModal: React.FC<FormDataModalProps> = ({
  isOpen,
  onClose,
  records,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [maskSensitive, setMaskSensitive] = useState(true);

  if (!isOpen) return null;

  const currentRecord = records[currentIndex];
  const total = records.length;

  const maskValue = (key: string, val: string | undefined): string => {
    if (!val) return 'N/A';
    if (!maskSensitive) return val;
    // Mask mobile numbers, PAN, Account numbers partially for privacy by default
    if (key.toLowerCase().includes('mobile') || key.toLowerCase().includes('phone')) {
      return val.length > 5 ? `${val.slice(0, 3)}****${val.slice(-3)}` : '******';
    }
    if (key.toLowerCase().includes('pan')) {
      return val.length > 4 ? `${val.slice(0, 2)}****${val.slice(-2)}` : '******';
    }
    return val;
  };

  const handleCopy = () => {
    if (!currentRecord) return;
    const text = Object.entries(currentRecord.fields)
      .map(([k, v]) => `${k} => ${v || ''}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm sm:max-w-md bg-white rounded-[26px] p-6 shadow-2xl border border-gray-100 relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button Top Right */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header matching Screenshot 5: "[ 1 ] Page Form Data" */}
        <div className="mb-5 pr-8">
          <h2 className="text-base sm:text-lg font-mono font-semibold text-[#202124]">
            [{' '}
            <span className="text-[#315FEA] font-bold">
              {total > 0 ? currentIndex + 1 : 0}
            </span>{' '}
            {total > 1 ? `/ ${total}` : ''} ] Page Form Data
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            Authorized client submitted form records
          </p>
        </div>

        {/* Content Body */}
        {total === 0 ? (
          <div className="py-8 text-center">
            <p className="text-sm font-medium text-gray-500">
              No form data submitted yet.
            </p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto pr-1 space-y-2 font-mono text-sm sm:text-base text-gray-700 select-text">
            {Object.entries(currentRecord.fields).map(([key, value]) => (
              <div key={key} className="flex items-start space-x-2 py-0.5">
                <span className="text-gray-500 lowercase shrink-0 font-medium">
                  {key}
                </span>
                <span className="text-gray-400 font-bold">=&gt;</span>
                <span className="text-[#202124] font-semibold break-all">
                  {maskValue(key, value)}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Privacy Mask Toggle & Controls */}
        <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between text-xs">
          <button
            onClick={() => setMaskSensitive(!maskSensitive)}
            className="flex items-center space-x-1.5 text-gray-500 hover:text-gray-800 transition-colors font-sans"
          >
            {maskSensitive ? (
              <>
                <EyeOff className="w-4 h-4 text-gray-400" />
                <span>Masked (Privacy Mode)</span>
              </>
            ) : (
              <>
                <Eye className="w-4 h-4 text-[#315FEA]" />
                <span className="text-[#315FEA] font-medium">Unmasked</span>
              </>
            )}
          </button>

          <button
            onClick={handleCopy}
            disabled={total === 0}
            className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium transition-colors font-sans"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Data</span>
              </>
            )}
          </button>
        </div>

        {/* Pagination if multiple records exist */}
        {total > 1 && (
          <div className="mt-4 flex items-center justify-between font-sans">
            <button
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-semibold bg-gray-100 disabled:opacity-40 text-gray-700 hover:bg-gray-200"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <span className="text-xs font-medium text-gray-400">
              Record {currentIndex + 1} of {total}
            </span>

            <button
              onClick={() => setCurrentIndex((prev) => Math.min(total - 1, prev + 1))}
              disabled={currentIndex === total - 1}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-semibold bg-gray-100 disabled:opacity-40 text-gray-700 hover:bg-gray-200"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
