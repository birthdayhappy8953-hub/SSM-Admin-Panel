import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { FourSquaresLogo } from './Icons';
import { Lock, Mail, AlertCircle, ArrowRight } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, isFirebaseActive } = useAuth();
  const [email, setEmail] = useState('admin@wizardx.panel');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await login(email, password);
    setLoading(false);
    if (!res.success) {
      setError(res.error || 'Authentication failed. Please verify credentials.');
    }
  };

  const handleQuickDemoAdmin = async () => {
    setEmail('admin@wizardx.panel');
    setPassword('admin123');
    setLoading(true);
    await login('admin@wizardx.panel', 'admin123');
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#F7F8FC]">
      <div className="w-full max-w-sm bg-white rounded-[28px] p-6 sm:p-8 shadow-[0_8px_30px_rgba(0,0,0,0.06)] border border-gray-100">
        {/* Logo and Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <FourSquaresLogo className="w-12 h-12 mb-3" />
          <h1 className="text-xl font-extrabold text-[#202124] tracking-tight">
            WizardX • SSM Panel
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Sign in to access authorized devices and message streams
          </p>
        </div>

        {/* Backend Mode Pill */}
        <div className="flex justify-center mb-5">
          <span
            className={`text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
              isFirebaseActive
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-blue-50 text-[#315FEA] border border-blue-200'
            }`}
          >
            {isFirebaseActive ? 'Firebase Auth Active' : 'Admin Session Gate'}
          </span>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center space-x-2 mb-4">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              Account Email
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@wizardx.panel"
                className="w-full bg-gray-50 border border-gray-200 focus:border-[#315FEA] rounded-2xl py-2.5 pl-9 pr-3 text-sm font-medium focus:outline-none transition-colors"
              />
              <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-gray-50 border border-gray-200 focus:border-[#315FEA] rounded-2xl py-2.5 pl-9 pr-3 text-sm font-medium focus:outline-none transition-colors"
              />
              <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#050505] hover:bg-[#1f1f1f] active:scale-[0.99] text-white font-bold py-3.5 px-4 rounded-full text-sm tracking-wide shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 mt-4 cursor-pointer"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Panel'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Demo Login Shortcut */}
        <div className="mt-5 pt-4 border-t border-gray-100 text-center">
          <button
            type="button"
            onClick={handleQuickDemoAdmin}
            className="text-xs font-semibold text-[#315FEA] hover:underline"
          >
            Quick 1-Click Administrator Access (id41)
          </button>
        </div>
      </div>
    </div>
  );
};
