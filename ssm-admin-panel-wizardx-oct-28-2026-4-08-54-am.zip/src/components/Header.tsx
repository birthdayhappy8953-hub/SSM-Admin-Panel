import React, { useState, useEffect } from 'react';
import { FourSquaresLogo, DemonIcon } from './Icons';
import { Mail, Database, Smartphone, Monitor } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  deviceCount: number;
  title?: string;
  onHomeClick: () => void;
  onSettingsClick: () => void;
  onQuickSmsClick: () => void;
  onFirebaseStatusClick: () => void;
  isMobileFrame: boolean;
  toggleMobileFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  deviceCount,
  title = '• WizardX Panel •',
  onHomeClick,
  onSettingsClick,
  onQuickSmsClick,
  onFirebaseStatusClick,
  isMobileFrame,
  toggleMobileFrame,
}) => {
  const { isFirebaseActive } = useAuth();
  const [timeString, setTimeString] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const day = String(now.getDate()).padStart(2, '0');
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const year = now.getFullYear();

      let hours = now.getHours();
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // 0 becomes 12
      const hoursStr = String(hours).padStart(2, '0');

      setTimeString(`${day}/${month}/${year} ${hoursStr}:${minutes}:${seconds} ${ampm}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="w-full bg-white rounded-2xl md:rounded-3xl shadow-[0_2px_12px_rgba(0,0,0,0.04)] px-3.5 py-2.5 sm:px-5 sm:py-3 mb-3 flex items-center justify-between border border-gray-100/80">
      {/* Left section: App logo & Count & Title */}
      <div className="flex items-center space-x-2.5 sm:space-x-3.5 min-w-0">
        <FourSquaresLogo className="w-7 h-7 sm:w-8 sm:h-8 shrink-0" onClick={onHomeClick} />

        <div className="bg-[#050505] text-white font-bold text-xs sm:text-sm px-2.5 py-1 rounded-full shrink-0 shadow-sm tracking-wide">
          {deviceCount}
        </div>

        <button
          onClick={onHomeClick}
          className="font-bold text-sm sm:text-base text-[#202124] tracking-tight hover:text-[#315FEA] transition-colors truncate focus:outline-none"
        >
          {title}
        </button>
      </div>

      {/* Right section: Live Time & Actions */}
      <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
        {/* Real-time ticking date and time in red/crimson font (as in screenshot) */}
        <div className="text-[#D32F2F] font-semibold text-[11px] sm:text-xs tracking-tight tabular-nums hidden xs:block">
          {timeString}
        </div>

        {/* Firebase indicator */}
        <button
          onClick={onFirebaseStatusClick}
          title={isFirebaseActive ? 'Connected to Firebase' : 'Interactive Preview Mode (Click for Firebase Config)'}
          className={`flex items-center space-x-1 text-[11px] font-semibold px-2 py-1 rounded-full transition-all ${
            isFirebaseActive
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span className="hidden md:inline">{isFirebaseActive ? 'Firebase Live' : 'Demo Mode'}</span>
        </button>

        {/* Responsive Frame Toggle (switch between Mobile Frame preview and desktop full-width) */}
        <button
          onClick={toggleMobileFrame}
          title={isMobileFrame ? 'Expand to Full Width' : 'Simulate Mobile Device Frame'}
          className="p-1.5 rounded-full text-gray-500 hover:text-gray-800 hover:bg-gray-100 transition-colors hidden sm:flex items-center justify-center"
        >
          {isMobileFrame ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
        </button>

        {/* Quick Send SMS Icon Button */}
        <button
          onClick={onQuickSmsClick}
          title="Compose / Forward SMS"
          className="w-8 h-8 rounded-full bg-[#315FEA] text-white flex items-center justify-center hover:bg-[#254cc4] active:scale-95 transition-all shadow-sm focus:outline-none"
        >
          <Mail className="w-4 h-4" />
        </button>

        {/* Demon/Devil Profile Trigger Icon */}
        <DemonIcon className="w-7 h-7 sm:w-8 sm:h-8" onClick={onSettingsClick} />
      </div>
    </header>
  );
};
