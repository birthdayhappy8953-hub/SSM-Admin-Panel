import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { firebaseConfig, isFirebaseConfigured } from '../firebase/config';
import { seedFirestore, fetchAuditLogs } from '../services/firestoreService';
import { AuditLog } from '../types';
import {
  Database,
  ShieldCheck,
  Check,
  Copy,
  X,
  Server,
  CloudLightning,
  AlertTriangle,
  History,
} from 'lucide-react';

interface FirebaseStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  deviceCount: number;
  messageCount: number;
}

export const FirebaseStatusModal: React.FC<FirebaseStatusModalProps> = ({
  isOpen,
  onClose,
  deviceCount,
  messageCount,
}) => {
  const { isFirebaseActive, currentUser } = useAuth();
  const [copiedEnv, setCopiedEnv] = useState(false);
  const [seedingStatus, setSeedingStatus] = useState<string | null>(null);
  const [isSeeding, setIsSeeding] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [activeTab, setActiveTab] = useState<'status' | 'rules' | 'audit'>('status');

  useEffect(() => {
    if (isOpen) {
      fetchAuditLogs().then(setAuditLogs);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const envSample = `# SSM Admin Panel - Firebase Configuration
VITE_FIREBASE_API_KEY="AIzaSyYourApiKeyHere..."
VITE_FIREBASE_AUTH_DOMAIN="${firebaseConfig.authDomain || 'your-project.firebaseapp.com'}"
VITE_FIREBASE_PROJECT_ID="${firebaseConfig.projectId || 'your-project-id'}"
VITE_FIREBASE_STORAGE_BUCKET="${firebaseConfig.storageBucket || 'your-project.appspot.com'}"
VITE_FIREBASE_MESSAGING_SENDER_ID="${firebaseConfig.messagingSenderId || '123456789012'}"
VITE_FIREBASE_APP_ID="${firebaseConfig.appId || '1:123456789012:web:abcdef123456'}"`;

  const handleCopyEnv = () => {
    navigator.clipboard.writeText(envSample);
    setCopiedEnv(true);
    setTimeout(() => setCopiedEnv(false), 2000);
  };

  const handleSeed = async () => {
    setIsSeeding(true);
    setSeedingStatus('Seeding Firestore collections...');
    const res = await seedFirestore();
    setIsSeeding(false);
    setSeedingStatus(res.message);
    fetchAuditLogs().then(setAuditLogs);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-white rounded-[26px] p-6 shadow-2xl border border-gray-100 relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-4 pr-8">
          <div className="w-10 h-10 rounded-2xl bg-[#315FEA]/10 text-[#315FEA] flex items-center justify-center shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-[#202124]">
              Firebase & Cloud Firestore Center
            </h2>
            <p className="text-xs text-gray-500">
              Configuration, collection status, security rules & audit logs
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-2 border-b border-gray-100 pb-2 mb-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('status')}
            className={`px-3 py-1.5 rounded-full transition-colors ${
              activeTab === 'status'
                ? 'bg-[#315FEA] text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Backend Status
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-1.5 rounded-full transition-colors ${
              activeTab === 'rules'
                ? 'bg-[#315FEA] text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Security Rules (RBAC)
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-1.5 rounded-full transition-colors flex items-center space-x-1 ${
              activeTab === 'audit'
                ? 'bg-[#315FEA] text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Logs</span>
          </button>
        </div>

        {/* Tab 1: Status */}
        {activeTab === 'status' && (
          <div className="space-y-4 overflow-y-auto pr-1">
            {/* Status Card */}
            <div
              className={`p-4 rounded-2xl border ${
                isFirebaseActive
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                  : 'bg-amber-50/80 border-amber-200 text-amber-950'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {isFirebaseActive ? (
                    <CloudLightning className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                  )}
                  <span className="font-bold text-sm">
                    {isFirebaseActive
                      ? 'Connected to Live Firebase'
                      : 'Interactive Preview & Local Persistence Mode'}
                  </span>
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    isFirebaseActive
                      ? 'bg-emerald-200 text-emerald-800'
                      : 'bg-amber-200 text-amber-800'
                  }`}
                >
                  {isFirebaseActive ? 'Live Cloud' : 'Preview'}
                </span>
              </div>
              <p className="text-xs mt-2 text-gray-700 leading-relaxed">
                {isFirebaseActive
                  ? `Active Project: ${firebaseConfig.projectId}. Authentication and Firestore operations are securely routing to your cloud instance.`
                  : 'Operating in self-contained interactive mode with realistic sample devices, message threads, and form records. All edits persist in local state.'}
              </p>
            </div>

            {/* Collections Grid */}
            <div>
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                Firestore Collections
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">devices</span>
                  <span className="text-base font-bold text-gray-800">{deviceCount} active</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">messages</span>
                  <span className="text-base font-bold text-gray-800">{messageCount} records</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">formRecords</span>
                  <span className="text-base font-bold text-gray-800">3 submitted</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">users</span>
                  <span className="text-base font-bold text-gray-800">1 (Admin)</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">appSettings</span>
                  <span className="text-base font-bold text-gray-800">Global Config</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-[11px] text-gray-400 block font-mono">auditLogs</span>
                  <span className="text-base font-bold text-gray-800">{auditLogs.length} events</span>
                </div>
              </div>
            </div>

            {/* Seed / Action Buttons */}
            {isFirebaseActive && (
              <div className="pt-2">
                <button
                  onClick={handleSeed}
                  disabled={isSeeding}
                  className="w-full bg-[#315FEA] hover:bg-[#254cc4] text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-sm transition-all disabled:opacity-50"
                >
                  <Server className="w-4 h-4" />
                  <span>{isSeeding ? 'Seeding...' : 'Seed Initial Data to Cloud Firestore'}</span>
                </button>
                {seedingStatus && (
                  <p className="text-xs text-center text-gray-600 mt-2 font-medium">
                    {seedingStatus}
                  </p>
                )}
              </div>
            )}

            {/* Environment Variables Card */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  Environment Configuration
                </span>
                <button
                  onClick={handleCopyEnv}
                  className="text-xs text-[#315FEA] hover:underline flex items-center space-x-1"
                >
                  {copiedEnv ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedEnv ? 'Copied' : 'Copy .env Keys'}</span>
                </button>
              </div>
              <pre className="bg-gray-900 text-gray-200 p-3 rounded-xl text-[11px] font-mono overflow-x-auto select-all">
                {envSample}
              </pre>
            </div>
          </div>
        )}

        {/* Tab 2: Security Rules */}
        {activeTab === 'rules' && (
          <div className="space-y-3 overflow-y-auto pr-1">
            <div className="flex items-center space-x-2 text-xs text-gray-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>
                Role-Based Access Control configured in <code className="font-mono bg-gray-100 px-1 py-0.5 rounded">firestore.rules</code>
              </span>
            </div>
            <pre className="bg-gray-900 text-emerald-400 p-3 rounded-xl text-[11px] font-mono overflow-x-auto leading-relaxed">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAuthenticated() { return request.auth != null; }
    function isAdmin() {
      return isAuthenticated() && 
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
    }

    match /users/{userId} {
      allow read, write: if isAuthenticated() && (request.auth.uid == userId || isAdmin());
    }
    match /devices/{deviceId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
    match /messages/{messageId} {
      allow read, write: if isAuthenticated();
    }
    match /formRecords/{recordId} {
      allow read, write: if isAdmin();
    }
  }
}`}
            </pre>
            <p className="text-[11px] text-gray-500">
              Deploy these rules with <code className="font-mono">firebase deploy --only firestore:rules</code>.
            </p>
          </div>
        )}

        {/* Tab 3: Audit Logs */}
        {activeTab === 'audit' && (
          <div className="space-y-2 overflow-y-auto pr-1 flex-1">
            <p className="text-xs text-gray-500 mb-2">
              Immutable administrative log of panel activities:
            </p>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-gray-400 py-4 text-center">No audit logs recorded yet.</p>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 bg-gray-50 rounded-xl border border-gray-100 text-xs">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-mono font-bold text-gray-800 bg-gray-200/70 px-1.5 py-0.5 rounded text-[10px]">
                      {log.action}
                    </span>
                    <span className="text-gray-400 text-[10px] tabular-nums font-mono">
                      {log.timestamp}
                    </span>
                  </div>
                  <div className="text-gray-600 font-medium">{log.details}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Actor: {log.actorEmail || log.actorUid}</div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
